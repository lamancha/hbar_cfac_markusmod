#ifndef _INIT_H_
#define _INIT_H_ 1

int Info(void);
int InitFac(void);

#endif
