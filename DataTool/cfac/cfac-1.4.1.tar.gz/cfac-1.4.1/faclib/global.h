#ifndef _GLOBAL_H_
#define _GLOBAL_H_ 1

#include "cfac.h"

extern cfac_t *cfac;

#endif /* _GLOBAL_H_ */
