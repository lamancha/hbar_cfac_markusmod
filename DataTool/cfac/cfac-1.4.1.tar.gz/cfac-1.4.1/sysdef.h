/* sysdef.h.  Generated from sysdef.h.in by configure.  */
/* this is a template for sysdef.h */
#ifndef _SYSDEF_H_ 
#define _SYSDEF_H_ 1

#define f2cFortran 1
/* #undef NAGf90Fortran */
/* #undef hpuxFortran */
/* #undef apolloFortran */
/* #undef sunFortran */
/* #undef IBMR2Fortran */
/* #undef CRAYFortran */
/* #undef mipsFortran */
/* #undef DECFortran */
/* #undef vmsFortran */
/* #undef CONVEXFortran */
/* #undef PowerStationFortran */
/* #undef AbsoftUNIXFortran */
/* #undef SXFortran */
/* #undef pgiFortran */
/* #undef AbsoftProFortran */

#endif
